/**
 * Author: Tsz-Chiu Au 
 * Email: chiu@unist.ac.kr 
 */

package mazegame;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class CppAgent {

    private final Process process;
    private final PrintWriter perceptWriter;
    private final Scanner actionReader;
    private final boolean isAStar;

    public CppAgent(int sizeX, int sizeY, String filename, boolean isAStar) throws IOException {
        ProcessBuilder pb = new ProcessBuilder("./" + filename, Integer.toString(sizeX), Integer.toString(sizeY));
        // pb.directory(new File("/Users/chiu/ai/prog_solution/hw1/bfs/"));
        // System.out.printf("dir = %s\n", System.getProperty("user.dir"));
        
        this.isAStar = isAStar;
        
        pb.redirectError(ProcessBuilder.Redirect.INHERIT);

        process = pb.start();
        InputStream is = process.getInputStream();
        OutputStream os = process.getOutputStream();
        
        perceptWriter = new PrintWriter(os, true);
        actionReader = new Scanner(new InputStreamReader(is));
    }
    
    public boolean getIsAStar() {
        return isAStar;
    }
    
    public Coordinate move(boolean isExit,
                           boolean hasWallSouth,
                           boolean hasWallNorth,
                           boolean hasWallEast,
                           boolean hasWallWest,
                           double distance) {

        perceptWriter.printf("%d %d %d %d %d", isExit?1:0, hasWallSouth?1:0, hasWallNorth?1:0, hasWallEast?1:0, hasWallWest?1:0);
        if (isAStar) {
            perceptWriter.printf(" %.8f\n", distance);
        } else {
            perceptWriter.printf("\n");
        }
        
        if (MazeGame.isVerbose) {
            System.out.printf("%d %d %d %d %d", isExit?1:0, hasWallSouth?1:0, hasWallNorth?1:0, hasWallEast?1:0, hasWallWest?1:0);
            if (isAStar) {
                System.out.printf(" %.8f\n", distance);
            } else {
                System.out.printf("\n");
            }
        }

        assert actionReader.hasNext();
        String s = actionReader.next();
        while (s.equals("#")) {
            System.out.printf("# %s\n", actionReader.nextLine());
            assert actionReader.hasNext();
            s = actionReader.next();
        }
        if (s.equals("PATH")) {
            if (MazeGame.isVerbose && !MazeGame.VERBOSE_INPUT_ONLY) {
                System.out.printf("PATH\n");
            } 
            return null;
        } else {
            int x = Integer.valueOf(s);
            assert actionReader.hasNext();
            s = actionReader.next();
            int y = Integer.valueOf(s);
            if (MazeGame.isVerbose && !MazeGame.VERBOSE_INPUT_ONLY) {
                System.out.printf("%d %d\n", x, y);
            }
            return new Coordinate(x, y);
        }
    }
    
    public List<Coordinate> getShortestPath() {
        List<Coordinate> path = new LinkedList<>();
        while(true) {
            String s = actionReader.next();
            if (s.equals("END")) {
                if (MazeGame.isVerbose && !MazeGame.VERBOSE_INPUT_ONLY) {
                    System.out.printf("END\n");
                }
                try {
                    process.waitFor();
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
                break;
            } else {
                int x = Integer.valueOf(s);
                assert actionReader.hasNext();
                s = actionReader.next();
                int y = Integer.valueOf(s);
                path.add(new Coordinate(x, y));
                if (MazeGame.isVerbose && !MazeGame.VERBOSE_INPUT_ONLY) {
                    System.out.printf("%d %d\n", x, y);
                }
            }
        }
        return path;
    }

}
