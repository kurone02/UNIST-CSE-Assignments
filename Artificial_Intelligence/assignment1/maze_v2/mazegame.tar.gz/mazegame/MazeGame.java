/**
 * Author: Tsz-Chiu Au and Olzhas Kaiyrakhmet (Nickname: olzhabay) 
 * Email: chiu@unist.ac.kr and olzhabay.i@gmail.com 
 */
package mazegame;

import java.util.Random;
import javax.swing.JFrame;

public class MazeGame {
    
    public static final long RANDOM_SEED = System.currentTimeMillis();
    public static final Random RANDOM = new Random(RANDOM_SEED);
    // public static final long RANDOM_SEED = 1000L;            

    public static boolean VERBOSE_INPUT_ONLY = false;
    public static boolean isVerbose = false;

    public static void main(String args[]) throws Exception {
        
        MazeFrame frame;
        
        if (args.length==0) {
            frame = new MazeFrame();
        } else if (args.length==1) {
            if (args[0].equals("-v")) {
                isVerbose = true;
                frame = new MazeFrame();
            } else {
                frame = new MazeFrame(args[0]);
            }
        } else {
            if (args[0].equals("-v")) {
                isVerbose = true;
                frame = new MazeFrame(args[1]);
            } else {
                frame = new MazeFrame(args[0]);
            }
        }
        
        assert frame != null;
        
        frame.setTitle("Maze");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

}
