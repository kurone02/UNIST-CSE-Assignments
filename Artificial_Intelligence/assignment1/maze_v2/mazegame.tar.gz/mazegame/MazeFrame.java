/**
 * Author: Tsz-Chiu Au and Olzhas Kaiyrakhmet (Nickname: olzhabay) 
 * Email: chiu@unist.ac.kr and olzhabay.i@gmail.com 
 */
package mazegame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;


class MazeFrame extends JFrame {

    private static final double NOISE_LEVEL = 0.2;
    private static final int DEFAULT_SIZE_X = 120;
    private static final int DEFAULT_SIZE_Y = 80;
            
    public enum SearchMode {
        ASTAR, DFS, BFS
    }
    private Maze maze;
    
    private List<Coordinate> visitedPos;
    private boolean[][] visitedPosMap;
    private List<Coordinate> shortestPath;
    private boolean[][] shortestPathMap;
    private boolean[][] errorMap;
    private int current_x, current_y;
    
    JButton startAgentButton;
    JButton generateButton;
    JButton clearMapButton;

    JTextField fieldSimDelay;
    
    AtomicBoolean isAllowedToDraw;

    private class MazePanel extends JPanel {

        private static final int CELL_SIZE = 5;
        private static final int PANEL_WIDTH = 900;
        private static final int PANEL_HEIGHT = 700;
        
        private static final int PANEL_ORIGIN_X = 25;
        private static final int PANEL_ORIGIN_Y = 25;
        private static final int POINT_RADIUS = 10;
        

        
        
        @Override
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int yRect = PANEL_ORIGIN_Y;
            Rectangle cell;
            for (int y = 0; y < maze.getSizeY(); y++) {
                int xRect = PANEL_ORIGIN_X;
                for (int x = 0; x < maze.getSizeX(); x++) {
                    g2.setPaint(getPositionColor(x, y));
                    cell = new Rectangle(xRect, yRect, CELL_SIZE, CELL_SIZE);
                    g2.fill(cell);
                    xRect += CELL_SIZE;
                }
                yRect += CELL_SIZE;
            }
            g2.setPaint(Color.BLUE);
            g2.drawOval(PANEL_ORIGIN_X + maze.getStartX() * CELL_SIZE + CELL_SIZE/2 - POINT_RADIUS,
                        PANEL_ORIGIN_Y + maze.getStartY() * CELL_SIZE + CELL_SIZE/2 - POINT_RADIUS,
                        POINT_RADIUS * 2, POINT_RADIUS * 2);
            g2.setPaint(Color.RED);
            g2.drawOval(PANEL_ORIGIN_X + maze.getFinishX() * CELL_SIZE + CELL_SIZE/2 - POINT_RADIUS,
                        PANEL_ORIGIN_Y + maze.getFinishY() * CELL_SIZE + CELL_SIZE/2 - POINT_RADIUS,
                        POINT_RADIUS * 2, POINT_RADIUS * 2);
            
            if (shortestPath.size() > 0) {
                // int memory = (int) Math.log10(Runtime.getRuntime().maxMemory() / 1024.0 / 1024.0) + 1;
                if (maze.getActualShortestDistance() == shortestPath.size()-1) {
                    g2.setPaint(Color.BLUE);
                } else {
                    g2.setPaint(Color.RED);
                }
                g2.drawString("Actual shortest distance = " + maze.getActualShortestDistance() +
                              ", The shortest distance you found = " + (shortestPath.size()-1) +
                              ", Number of moves = " + (visitedPos.size() - 1),
                              10, 16);
//                g2.drawString("Actual shortest distance = " + maze.getActualShortestDistance() +
//                              ", The shortest distance you found = " + (shortestPath.size()-1) +
//                              ", Number of moves = " + (visitedPos.size() - 1) +
//                              ", Memory usage = " + memory + "MB", 10, 16);
            } else {
                g2.setPaint(Color.DARK_GRAY);
                g2.drawString("Actual shortest distance = " + maze.getActualShortestDistance(), 10, 16);
            }
        }
        
        private Color getPositionColor(int x, int y) {
            if (errorMap[x][y]) {
                return Color.PINK;
            } else if (x == maze.getStartX() && y == maze.getStartY()) {
                return Color.blue;
            } else if (x == maze.getFinishX() && y == maze.getFinishY()) {
                return Color.red;
            } else if (shortestPathMap[x][y]) {
                return Color.orange;
            } else if (x == current_x && y == current_y) {
                return Color.MAGENTA;
            } else if (visitedPosMap[x][y]) {
                return Color.green;
            } else if (maze.isWall(x, y)) {
                return Color.DARK_GRAY;
            } else { // empty space
                return Color.white;
            }
        }
        
        @Override
        public Dimension getPreferredSize(){//no comment)
            return new Dimension(PANEL_WIDTH, PANEL_HEIGHT);
        }

    }

    // -------------------------------------------
    //    Constructor
    // -------------------------------------------
    
    public MazeFrame() {
        maze = new Maze(DEFAULT_SIZE_X, DEFAULT_SIZE_Y);
        setup();
    }
    
    public MazeFrame(String fileName) {
        maze = new Maze(fileName);
        setup();
    }

    private void setup() {
        resetState();
        
        //maze graphic component
        final MazePanel mazePanel = new MazePanel();

        //Height,Width Fields
        final JTextField fieldWidth = new JTextField(Integer.toString(maze.getSizeX()));
        final JTextField fieldHeight = new JTextField(Integer.toString(maze.getSizeY()));
        fieldSimDelay = new JTextField(Integer.toString(5));

        //Generate Button Button
        generateButton = new JButton("Generate new maze");
        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int xNumCells = Integer.parseInt(fieldWidth.getText());
                int yNumCells = Integer.parseInt(fieldHeight.getText());
                if (xNumCells < 3 || xNumCells > 300 || yNumCells < 3 || yNumCells > 300 || (xNumCells - 2) * (yNumCells - 2) < 2) {
                    JOptionPane.showMessageDialog(null, "Invalid maze size.");
                } else {
                    maze = new Maze(xNumCells, yNumCells);
                    resetState();
                    repaint();
                }
            }
        });

        //Clear Map Button
        clearMapButton = new JButton("Clear Map");
        clearMapButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                resetState();
                repaint();
            }
        });


        //panel with generation button and fields
        JPanel generationPanel = new JPanel();
        generationPanel.setLayout(new GridLayout(6, 1));
        generationPanel.add(new JLabel("Width :", SwingConstants.LEFT));
        generationPanel.add(fieldWidth);
        generationPanel.add(new JLabel("Height :", SwingConstants.LEFT));
        generationPanel.add(fieldHeight);
        generationPanel.add(generateButton);
        generationPanel.add(clearMapButton);
        generationPanel.setBorder(BorderFactory.createEtchedBorder());

        //check box and radio buttons
        final JRadioButton bfsButton = new JRadioButton("BFS search", true);
        final JRadioButton aStarButton = new JRadioButton("A-star search", false);
        final JRadioButton dfsButton = new JRadioButton("DFS search", false);

        ButtonGroup searchButtonGroup = new ButtonGroup();
        searchButtonGroup.add(bfsButton);
        searchButtonGroup.add(aStarButton);
        searchButtonGroup.add(dfsButton);

        //Start Rat button
        startAgentButton = new JButton("Start Agent");
        startAgentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    if (aStarButton.isSelected()) {
                        startAgent(SearchMode.ASTAR);
                    } else if (dfsButton.isSelected()) {
                        startAgent(SearchMode.DFS);
                    } else { // bfsButton. isSelected()
                        startAgent(SearchMode.BFS);
                    }
                } catch (IOException ex) {
                    System.err.printf("Cannot open the file.\n");
                    ex.printStackTrace();
                    // Logger.getLogger(MazeFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
                repaint();
            }
        });

        //Agent panel
        JPanel agentSearchPanel = new JPanel();
        agentSearchPanel.setLayout(new GridLayout(6, 1));
        agentSearchPanel.add(bfsButton);
        agentSearchPanel.add(aStarButton);
        agentSearchPanel.add(dfsButton);
        agentSearchPanel.add(startAgentButton);
        
        agentSearchPanel.add(new JLabel("Simulation Delay (milliseconds) :", SwingConstants.LEFT));
        agentSearchPanel.add(fieldSimDelay);
        
        agentSearchPanel.setBorder(BorderFactory.createEtchedBorder());

        //info panel
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(8, 1));
        infoPanel.add(new JLabel("* Walls are black"));
        infoPanel.add(new JLabel("* Empty spaces are white"));
        infoPanel.add(new JLabel("* The starting point is blue"));
        infoPanel.add(new JLabel("* The exit is red"));
        infoPanel.add(new JLabel("* Visited spaces are green"));
        infoPanel.add(new JLabel("* User's shortest path is orange"));
        infoPanel.add(new JLabel("* The current position is magenta"));
        infoPanel.add(new JLabel("* Errors are pink"));
        infoPanel.setBorder(BorderFactory.createEtchedBorder());

        //adding everything to each other
        JPanel westPanel = new JPanel();
        westPanel.setLayout(new GridLayout(3, 1));
        westPanel.add(generationPanel);
        westPanel.add(agentSearchPanel);
        westPanel.add(infoPanel);
        add(mazePanel, BorderLayout.CENTER);
        add(westPanel, BorderLayout.WEST);
    }
    
    public void resetState() {
        visitedPos = new LinkedList<>();
        shortestPath = new LinkedList<>();
        visitedPosMap = new boolean[maze.getSizeX()][maze.getSizeY()];
        shortestPathMap = new boolean[maze.getSizeX()][maze.getSizeY()];
        errorMap = new boolean[maze.getSizeX()][maze.getSizeY()];
        
        for(int i=0; i<maze.getSizeX(); i++) {
            for(int j=0; j<maze.getSizeY(); j++) {
                visitedPosMap[i][j] = false;
                shortestPathMap[i][j] = false;
                errorMap[i][j] = false;
            }
        }
        
        current_x = -1;
        current_y = -1;
        
        isAllowedToDraw = new AtomicBoolean(true);
    }

    private boolean myDraw(SearchMode mode, CppAgent agent, double distFactor) {
        
        visitedPos.add(new Coordinate(current_x, current_y));
        visitedPosMap[current_x][current_y] = true;

        boolean isExit = (maze.getFinishX() == current_x && maze.getFinishY() == current_y);

        Coordinate coordinate = null;

        assert agent != null;

        switch (mode) {
            case BFS:
                coordinate = agent.move(isExit,
                                        maze.hasSouthWall(current_x, current_y),
                                        maze.hasNorthWall(current_x, current_y),
                                        maze.hasEastWall(current_x, current_y),
                                        maze.hasWestWall(current_x, current_y),
                                        0.0);
                break;
            case ASTAR:
                double dist = maze.getEuclideanDistance(current_x, current_y);
                double scaledDist = dist * distFactor;
                coordinate = agent.move(isExit,
                                        maze.hasSouthWall(current_x, current_y),
                                        maze.hasNorthWall(current_x, current_y),
                                        maze.hasEastWall(current_x, current_y),
                                        maze.hasWestWall(current_x, current_y),
                                        scaledDist);
                break;
            case DFS:
                coordinate = agent.move(isExit,
                                        maze.hasSouthWall(current_x, current_y),
                                        maze.hasNorthWall(current_x, current_y),
                                        maze.hasEastWall(current_x, current_y),
                                        maze.hasWestWall(current_x, current_y),
                                        0.0);
                break;
        }

        if (coordinate == null) {
            drawShortestPath(agent);
            return false;
        } else {
            current_x = maze.getStartX() + coordinate.getX();
            current_y = maze.getStartY() + coordinate.getY();

            if (!checkValidMove(current_x, current_y, visitedPosMap)) {
                return false;
            }

            repaint();

            return true;
        }
    }
    
    private void drawShortestPath(CppAgent agent) {
        // Get the shortest path from the search algorithms.
        List<Coordinate> path = agent.getShortestPath();
        boolean isFirst = true;
        int last_x2 = maze.getStartX();
        int last_y2 = maze.getStartY();
        for(Coordinate a : path) {
            int x2 = maze.getStartX() + a.getX();
            int y2 = maze.getStartY() + a.getY();
            if ((0 <= x2) && (x2 < maze.getSizeX()) && (0 <= y2) && (y2 < maze.getSizeY())) {
                shortestPath.add(new Coordinate(x2, y2));
                shortestPathMap[x2][y2] = true;
            }
            if (isFirst) {
                if (x2 != maze.getStartX() || y2 != maze.getStartY()) {
                    errorMap[x2][y2] = true;
                    repaint();
                    JOptionPane.showMessageDialog(this, "The shortest path starts at (" + x2 + "," + y2 + "), which is not the starting point.");
                }
                isFirst = false;
            } else {
                if (!((0 <= x2) && (x2 < maze.getSizeX()) &&
                      (0 <= y2) && (y2 < maze.getSizeY())))
                {
                    errorMap[x2][y2] = true;
                    repaint();
                    JOptionPane.showMessageDialog(this, "The shortest path extends out of the maze at (" + x2 + "," + y2 + ").");
                }
                if (maze.isWall(x2, y2)) {
                    errorMap[x2][y2] = true;
                    repaint();
                    JOptionPane.showMessageDialog(this, "The shortest path passes through wall at (" + x2 + "," + y2 + ").");
                }
                if (!visitedPosMap[x2][y2]) {
                    errorMap[x2][y2] = true;
                    repaint();
                    JOptionPane.showMessageDialog(this, "The shortest path includes (" + x2 + "," + y2 + "), which has not been visited before.");
                }
                if (!((x2 == last_x2 - 1 && y2 == last_y2) ||
                      (x2 == last_x2 + 1 && y2 == last_y2) ||
                      (x2 == last_x2 && y2 == last_y2 - 1) ||
                      (x2 == last_x2 && y2 == last_y2 + 1)))
                {
                    errorMap[x2][y2] = true;
                    repaint();
                    JOptionPane.showMessageDialog(this, "The shortest path includes (" + x2 + "," + y2 + "), which is not adjacent to the previous location.");
                }
            }
            last_x2 = x2;
            last_y2 = y2;
        }
        if (maze.getFinishX() != last_x2 || maze.getFinishY() != last_y2) {
            repaint();
            JOptionPane.showMessageDialog(this, "The last position of the shortest path is not an exit.");
        } else {
            current_x = -1;
            current_y = -1;
            repaint();  // last draw
        }
    }

    private CppAgent createAgent(SearchMode mode) throws IOException {
        CppAgent agent = null;
        switch (mode) {
        case BFS:
            if (!(new File("bfs")).exists()) {
                JOptionPane.showMessageDialog(this, "Cannot find the agent named \"bfs\".");
            } else {
                agent = new CppAgent(maze.getSizeX(), maze.getSizeY(), "bfs", false);
            }
            break;
        case ASTAR:
            if (!(new File("astar")).exists()) {
                JOptionPane.showMessageDialog(this, "Cannot find the agent named \"astar\".");
            } else {
                agent = new CppAgent(maze.getSizeX(), maze.getSizeY(), "astar", true);
            }
            break;
        case DFS:
            if (!(new File("dfs")).exists()) {
                JOptionPane.showMessageDialog(this, "Cannot find the agent named \"dfs\".");
            } else {
                agent = new CppAgent(maze.getSizeX(), maze.getSizeY(), "dfs", false);
            }
            break;
        }
        return agent;
    }    
    
    public void startAgent(SearchMode mode) throws IOException {

        CppAgent agent = createAgent(mode);
        
        resetState();
        
        current_x = maze.getStartX();
        current_y = maze.getStartY();
        
        double distFactor = 1.0 + (MazeGame.RANDOM.nextDouble() - 0.5) * NOISE_LEVEL;
        
        int simDelay = Integer.parseInt(fieldSimDelay.getText());
        
        if (simDelay <= 0) {
            while (true) {
                if (!myDraw(mode, agent, distFactor)) {
                    break;
                }
            }
        } else {
            startAgentButton.setEnabled(false);
            generateButton.setEnabled(false);
            clearMapButton.setEnabled(false);
        
            final Timer timer = new Timer(simDelay, new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                    
                    if (isAllowedToDraw.compareAndSet(true, false)) {
                        if (!myDraw(mode, agent, distFactor)) {
                            startAgentButton.setEnabled(true);
                            generateButton.setEnabled(true);
                            clearMapButton.setEnabled(true);
                            ((Timer)ae.getSource()).stop();
                        }
                        isAllowedToDraw.set(true);
                    }
                }
            });
            timer.start();
        }
    }

    private boolean checkValidMove(int x, int y, boolean[][] visitedLocation) {
        if (!((0 <= x) && (x < maze.getSizeX()) &&
              (0 <= y) && (y < maze.getSizeY()))) {
            errorMap[x][y] = true;
            repaint();
            JOptionPane.showMessageDialog(this, "Illegal move. Moving out of the maze at (" + x + "," + y + ").");
            return false;
        }
        if (maze.isWall(x, y)) {
            errorMap[x][y] = true;
            repaint();
            JOptionPane.showMessageDialog(this, "Illegal move. Cannot pass through wall at (" + x + "," + y + ").");
            return false;
        }
//        if (visitedLocation[x][y]) {
//            errorMap[x][y] = true;
//            repaint();
//            JOptionPane.showMessageDialog(this, "Illegal move. (" + x + "," + y + ") has visited before.");
//            return false;
//        }
        if ( ( (x == 0) || !visitedLocation[x-1][y] ) &&
             ( (x == maze.getSizeX()-1) || !visitedLocation[x+1][y] ) &&
             ( (y == 0) || !visitedLocation[x][y-1] ) &&
             ( (y == maze.getSizeY()-1) || !visitedLocation[x][y+1] ) )
        {
            errorMap[x][y] = true;
            repaint();
            JOptionPane.showMessageDialog(this, "Illegal move. (" + x + "," + y + ") is not adjacent to any visited location.");
            return false;
        }
        return true;
    }

}
