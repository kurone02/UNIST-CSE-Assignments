/*
    Student name: Nguyen Minh Duc
    Student ID: 20202026

    This is functions.h where it contains contains prototypes for factorial and probability.
*/

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

double factorial(int);

double probability(int, int);

#endif