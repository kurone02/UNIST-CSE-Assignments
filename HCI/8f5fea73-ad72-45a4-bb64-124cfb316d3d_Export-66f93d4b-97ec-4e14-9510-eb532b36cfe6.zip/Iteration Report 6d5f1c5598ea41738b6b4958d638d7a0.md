# Iteration Report

Making a low fidelity paper prototype for a mobile application is a crucial stage in the design process since it enables us to test and refine our design concepts and spot possible usability problems. It also allows us to quickly test and iterate on our design without investing too much time or resources. By making a physical prototype of the user interface of our application, we can simulate user interactions and get feedback on the usability through user survey and interview. It is an essential process in order to identify any design flaws and implement fixes early in the design process to improve user experience. 

1. **Pre-prototype: Target User Study**

i. **Participants**

- A total of 61 participants from various countries and academic backgrounds at UNIST were surveyed.
- Countries represented: Korea, Kazakhstan, Vietnam, India, Indonesia, Turkey, Philippines, Dominican Republic, Turkmenistan
- Age range: 20-28 years old
- Gender: Not specified
- Academic backgrounds: Biomedical Engineering, Computer Science and Engineering, Materials Science and Engineering, Energy and Chemical Engineering, Business Administration, Mechanical Engineering, Biological Sciences, Urban and Environmental Engineering
- Year of study: Undergraduate and graduate students

ii. **Tasks**

- The participants were asked to complete a survey about their fitness goals, exercise habits, and tracking methods.
- The survey included questions about the following:
    - Their fitness goals
    - Their exercise habits
    - The methods they use to track their progress
    - The challenges they face in tracking their progress
    - The features they would like to see in a fitness tracking app

iii. **Research Method**

- The survey was conducted using Google Forms.
- The survey was open for a period of two weeks.
- A total of 61 participants completed the survey.

iv. **Results**

![Untitled](Iteration%20Report%206d5f1c5598ea41738b6b4958d638d7a0/Untitled.png)

The majority of participants expressed an interest in losing weight, lowering body fat, and building up muscle. Exercise/working out and calorie deficit/surplus were the most common methods used to achieve their fitness goals.

Calorie tracking applications, mental noting, and journaling were the most common tracking methods used by participants. The most commonly tracked data were calorie intake and macronutrient intake.

The most common reason for tracking was to have a better understanding of their calorie intake and to ensure they were meeting their fitness goals. The most common barriers to tracking were lack of time and difficulty in finding accurate information about the food they consumed.

In terms of features, participants expressed interest in an app that could suggest healthy meals based on their fitness goals and dietary restrictions. They also expressed interest in a feature that could automatically detect the calories and macronutrients in their food.

**Statistics**

Percentage of participants interested in losing weight: 77%

Percentage of participants interested in building up muscle: 62%

Percentage of participants who use exercise/working out to achieve their fitness goals: 84%

Percentage of participants who use calorie tracking to achieve their fitness goals: 61%

Percentage of participants who track their calorie intake: 84%

Percentage of participants who track their macronutrient intake: 59%

Percentage of participants who find tracking difficult due to lack of time: 54%

Percentage of participants who find tracking difficult due to lack of accurate information: 39%

1. **Prototype #1 Paper Prototype**

a. **Design**

In order to make a low fidelity paper prototype of the user interface, we used common supplies including paper, markers, tape, stickers and colored pencils. Our key objective was to quickly repeat our user interface design and make changes to it without much difficulty when we found better approaches for the same design issues.

![Untitled](Iteration%20Report%206d5f1c5598ea41738b6b4958d638d7a0/Untitled%201.png)

We initially spoke about our design approach as a team before getting started with actual materials. We identified the main features of our application and concentrated on how to display these features. We then discussed the number of screens required for each functionality. After identifying each screen we need in our application, we sorted them from the most important feature to least important. According to the importance of these functions inside our application, we wanted to provide access to them concurrently. 

Since food analysis from an instantly taken picture is our application's primary feature, we chose to make that feature the homepage for easier access. As it is the main reason why people will use our application, we did not want users to have to navigate through several screens in order to reach the appropriate screen.

Then we made the decision to add two primary navigation buttons to the top of the screen, one for the menu that shows the remaining features and the other for going back to the home page. For the menu, we decided to organize each element on the menu in accordance with the prior determination of importance. We used the white board that was set up in the space where we had our group meetings throughout this process to communicate with each other about the specific design ideas we had. Additionally, we did several sketches before moving on to making paper prototype.

We began sketching up each screen on sheets that we cut to the actual size of a typical phone once we had identified all the features on each of these pages, such as buttons, menus, and forms. To make this procedure easier, we made the drawings by hand rather than using computer tools. The designs we came up with for this prototype were as straightforward as feasible and contained just the features that were absolutely necessary to communicate the design concept. We did not use detailed designs for icons and graphs. However, we simply used colored markers to give the users a better understanding since the color choices is also a solution for some usability problems.

After completing sketching each screen, we lay them on a surface and went through different navigation scenarios to see which sequence was most practical. We taped the screens together in a horizontal line once they had been arranged. To show the buttons that must be hit to advance to the screen that follows the current one, we used a little red arrow. We assigned numbers to buttons on screens where there are many button options in order to make it clearer which screen comes next. Then, we cut a phone frame out of paper and colored it with a black marker. After merging it with another piece of paper of the same size, we used it to pass through the screens we taped together. 

![Untitled](Iteration%20Report%206d5f1c5598ea41738b6b4958d638d7a0/Untitled%202.png)

![Untitled](Iteration%20Report%206d5f1c5598ea41738b6b4958d638d7a0/Untitled%203.png)

![Untitled](Iteration%20Report%206d5f1c5598ea41738b6b4958d638d7a0/Untitled%204.png)

b. **Design Justification**

The information architecture of our calorie counting application has been thoughtfully designed to guide users through a seamless and intuitive journey. The flow of the application is structured to ensure users can efficiently track their daily calorie intake, monitor their progress, and receive personalized suggestions to achieve their health goals.

1. **Sign-Up**: The user journey begins on the main page, where new users can sign up for an account. The sign-up process includes filling out profile information, such as full name, username, email, password.
2. **Health Information and Goal Setting**: After signing up, users are directed to provide additional health information, such as age, gender, weight, height for the automatically body mass index (BMI) calculation. Following this, users are prompted to set their calorie intake goals for the day or a general target based on their preferences and objectives.
3. ******************************Main page:****************************** The big circle in the middle shows how much calories left for a day. And right below that, there are 2 icons for calorie input. The icon in the top left corner shows the menu features and the one in the top right corner to straightly return to the Main Page when users are interacting to features in other pages.
4. **Calorie Input**: The user is then directed to a page where they can input their calorie intake. Our application offers two options for entering calories:
    1. **Food Image Recognition**: Users can take a picture of their food, and our embedded AI and database will analyze the image to provide details and a breakdown of the calories and macronutrients in the food.
    2. **Manual Input**: Alternatively, users can manually enter their calorie intake by typing in the relevant information.
5. **Weekly Intake**: After recording the calorie intake, users can navigate to the weekly intake screen. This screen provides a comprehensive overview of their calorie consumption for the week, allowing them to track their progress and identify any patterns or trends.
6. **Goals**: To further support users in achieving their health goals, the application suggests actions based on their calorie intake. These suggestions might include eating more protein, reducing sugar intake.
7. **My checklists**: This feature is like a user’s note. Users could add their own have-to-do things such as drinking more water, waking up at 8am, go jogging for 30 minutes/day. Users can remind themselves by going to this feature. 
8. **Profile Page**: Lastly, users can access their profile page, where they can view and update their personal information such as password, email address and health information as age, height, weight. 

The information architecture described above aims to create a logical and streamlined user experience, ensuring that users can easily navigate through the different stages of calorie tracking, receive personalized feedback, and stay motivated on their health journey.

c. **User Study // Thu**

1. **Participants:** 
- 3
- After creating the very first paper prototype, the first user study was conducted by our team. We created a small interview session with 7 users who have experience with using calorie-tracking applications. We interview users with 1st paper prototype and card interaction for UX/UI and functionalities, which lasts for about 10 minutes for each user. **The question set was created based on the paper prototype and we collected their opinions for further improvements to the next paper prototype. Users were asked to freely talk about the usability and design of a paper prototype for a calorie counting application. We asked for opinions on different functions, buttons, and actions on the screen, as well as suggestions for changes or improvements to the design. Some questions are also about potential missing features or functionalities that users would like to see added to the application. Our interview question set as follow:
1. Can you tell me your first impression of the application?
2. What do you think the different buttons or actions on the screen do? Are they intuitive enough? Is there anything you would suggest to change?
3. Were there any parts of the paper prototype that confused you or were difficult to understand?
4. Can you suggest any changes or improvements to the design?
5. How would you rate the overall usability of the paper prototype on a scale of 1-10?
6. Is there anything you would have expected to see or be able to do that you can't find on the prototype?
7. Are there features that you think we should add after seeing this application?
8. **Tasks**
9. **Research Method**
10. **Results**

d. **Insights and Reflections // Thu**

The user interface (UI) design for Tidbit is currently in its early stages and should be considered as a rough representation of our vision. Our intention is to continuously refine and enhance the UI to create a more polished and engaging experience for our users.

At this stage, the UI design is focused on providing a functional layout that allows users to easily track their daily calorie intake. However, we acknowledge that the design lacks the desired liveliness and fails to fully convey a sense of health or being healthy, which is a crucial aspect of our application's purpose.

Moving forward, we aim to incorporate vibrant and energetic visual elements that promote a positive and health-oriented atmosphere. This includes exploring color schemes that evoke feelings of vitality and well-being, as well as integrating relevant imagery such as fresh fruits, vegetables, and active individuals engaging in exercise.

We also plan to introduce interactive elements and animations that provide visual feedback to users, enhancing their engagement with the application. These additions will contribute to creating a more lively and dynamic UI that aligns with the overall goal of fostering a healthy lifestyle.

As our design evolves, we will seek feedback from our target users through usability testing and user surveys to ensure that the final UI design successfully captures the essence of health and well-being, while remaining intuitive and user-friendly.

1. **Prototype #2 Computer Prototype**

a. **Design** 

In this section, we will describe the design strategy used for Tidbit. Our proposed calorie counting application's design strategy incorporates both aesthetically pleasing and practical components, with the primary goal of developing a simple, straightforward user experience that is tailored to assist users in tracking their daily calorie intake. We drew a low-fide computer prototype with some changes with the paper one based on our insights after the user study.

![First Computer Prototype.png](Iteration%20Report%206d5f1c5598ea41738b6b4958d638d7a0/First_Computer_Prototype.png)

b. **Design Justification**

The design decisions made for Tidbit are driven by a user-centric approach, with a focus on creating an intuitive, visually engaging, and health-oriented user interface (UI). The following justifications explain why specific design choices were made:

- **User-Centric UI**: While our UI is currently in the rough sketch phase, the design concept revolves around utilizing graphs and visual elements to represent data in a more intuitive and meaningful way. By presenting information through visually appealing and easily understandable visualizations (making the calories left as the fluid wave in the big circle of the Main Page), we aim to enhance user comprehension and engagement with their calorie tracking and nutritional data.
- **Readable Font Sizes**: To ensure optimal readability, we have chosen font sizes that are easily legible for users. This decision is crucial to facilitate effortless consumption of information and reduce the cognitive load for users. Clear and appropriately sized fonts contribute to a positive user experience, allowing users to access and understand their calorie intake data without strain or confusion.
- **Color Scheme and Health Association**: Although the specific color scheme has not been finalized, our design direction is to use colors that are commonly associated with health and well-being. By selecting colors (teal and orange, that are complementary colors) related to nature, freshness, and vitality, we aim to create a visual atmosphere that reinforces the application's purpose of promoting a healthy lifestyle. The color scheme will be carefully chosen to create a harmonious and visually appealing UI, while also ensuring that the text and data remain easily readable and accessible to users.
- **Flow of Screens**: The flow of screens within the application has been carefully planned to ensure a seamless and intuitive user experience. The progression from the main page to the sign-up page, profile information, health details, and goal setting allows users to provide essential information for accurate calorie tracking. The subsequent screens for calorie input, weekly intake overview, calendar, and personalized suggestions follow a logical sequence that aligns with users' needs and goals. This thoughtful screen flow enables users to navigate the application effortlessly and make the most of its features.
- ************************Adding titles for calories input’s icons:************************ Only icons themselves sometimes make users confused, therefore, we added texts to guild users to choose input method.
- **********************Switch My Checklists feature to BMI Calculation feature:**********************  As from user study, My Checklists is not that necessary, instead, because the weight of users could be varies day by day, they might need to recalculate BMI scores more often to decide their specific goals and the amount of calories intake per day.
- **Calendar and Historical Data**: Users can access a calendar function to view their calorie intake history from previous dates. This functionality enables users to review and compare their daily intake, facilitating self-reflection and informed decision-making.

These design choices aim to provide users with a clear and structured pathway to navigate through different stages of the calorie tracking process. By presenting screens in a coherent flow, users can easily comprehend the app's functionalities and transition smoothly between tasks. This intuitive screen flow reduces user confusion and enhances overall usability, contributing to a positive and engaging user experience.

The combination of a user-friendly UI, visually appealing data representations, readable font sizes, a health-associated color scheme, and a carefully planned screen flow all work together to create an application that is not only visually appealing but also highly functional and conducive to promoting a healthy lifestyle.

**************************c. User Study**************************

1. **Participants** 
2. **Tasks**
3. **Research Method**
4. **Results**

******d. Insights and Reflections******

We learned important lessons and had important realizations while we developed our calorie tracking application, Tidbit, and these things had a big impact on the design that was ultimately chosen. These observations were made as a result of user input, iterative design, and our user survey, which highlighted areas that needed enhancing and adjusting. The main conclusions and reflections are as follows:

1. **User Study Findings**: The user study provided valuable feedback regarding the application's visual appeal and cohesiveness. Participants emphasized the importance of a professional and polished look, indicating the need for a more cohesive color scheme, refined font choices, and improved iconography. These insights have underscored the significance of elevating the application's aesthetic elements to enhance user perception and engagement.
2. **Design Considerations**: The design choices made, such as incorporating graphs and visual elements for data representation and using readable font sizes, were driven by the desire to create an intuitive and visually appealing user interface. However, the user study findings have reinforced the importance of taking these considerations further by ensuring a cohesive and professional visual presentation throughout the application.
3. **Iterations and Continuous Improvement**: The design process and user study have highlighted the importance of iterations in refining and enhancing the application's design. We have realized that iterations allow us to incorporate user feedback, address usability concerns, and make iterative improvements. This realization has reinforced our commitment to an iterative design approach, where we continuously refine and evolve the application to better meet user needs and aspirations.
4. **Flow and Usability**: The user study highlighted the need to carefully review the flow and organization of features within the application. Participants expressed the importance of intuitive navigation and seamless transitions between screens. As a result, we recognize the significance of revisiting the flow of screens and refining the placement and prominence of icons to ensure a more intuitive user experience.
5. **Color Scheme and Font Choices**: Based on user study feedback, we have realized the need to revisit and carefully select a color scheme that aligns with health and well-being, evoking a sense of vitality and freshness. Additionally, font choices will be reconsidered to ensure optimal readability and a professional aesthetic that enhances the overall user experience.
6. **Design Cohesion and Professionalism**: Our reflections have highlighted the significance of a cohesive and professional design that instills user confidence and trust. We acknowledge the importance of considering the application as a holistic experience, where visual elements, font choices, color scheme, and iconography work together harmoniously to create a polished and professional interface.

These observations have been a great source of direction for our design approach, ensuring that we successfully address user needs and objectives. We hope to develop an application that not only offers customers great functionality but also delights them with its visual appeal and usability by incorporating user feedback and thinking back on our design decisions.

Moving forward, we will embrace the iterative nature of design and use user insights and feedback to motivate ongoing development. We are confident in our abilities to develop a calorie counting application that effortlessly combines usability, user experience, and visual appeal by iteratively improving the design.