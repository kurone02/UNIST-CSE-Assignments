Promise.all([
    d3.csv('data/fertility_rate.csv'),
    d3.csv('data/life_expectancy.csv'),
    d3.csv('data/population.csv')
]).then(function(files) {
    const fertility = files[0]
    const life = files[1]
    const population = files[2]
    console.log(files)
    const getdata = (fert, life_ex, pop) => { 
        const year = [1960,1961,1962,1963,1964,1965,1966,1967,1968,1969,1970,1971,1972,1973,1974,1975,1976,1977,1978,1979,1980,1981,1982,1983,1984,1985,1986,1987,1988,1989,1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022]
        let ret = [];

        year.forEach((curr_year) => {
            const unique = [...new Set(pop.map((item) => item['Country Name']))];
            let retTemp = [];
            for (i in unique){
                const country = unique[i]
                const [getit_fert] = fert.filter(el => el['Country Name'] == country);
                const [getit_life] = life_ex.filter(el => el['Country Name'] == country);
                const [getit_pop] = pop.filter(el => el['Country Name'] == country);
                
                const map = {};
                map['year'] == curr_year;
                map['country_name'] = country;
                map['fertility'] = +getit_fert[`${curr_year}`];
                map['life_expectancy'] = +getit_life[`${curr_year}`];
                map['population'] = +getit_pop[`${curr_year}`];
               
                retTemp.push(map);
            }
            ret.push(retTemp);
        });
       
        return ret;
    }

    processedData = getdata(files[0], files[1], files[2]);

    console.log(processedData);
        
    // Add the year slider
    const slider = document.createElement('input');
    slider.type = 'range';
    slider.min = 0;
    slider.max = processedData.length - 1;
    slider.value = 0;
    slider.addEventListener('input', function() {
        selectedYear = processedData[this.value];
        drawBubbleChart(selectedYear);
    });

    // Append the slider to the page
    document.getElementById('slider-container').appendChild(slider);

    // Draw the chart 
    // drawBubbleChart(processedData[0]);

}).catch(error => {
    console.error(error);
    console.error('Error loading the data');
})

function drawBubbleChart(data){
    
    const margin = {top: 5, right: 100, bottom: 50, left: 50},
    width = 900 - margin.left - margin.right,
    height = 600 - margin.top - margin.bottom;

    d3.select("#chart").selectAll("*").remove();

//     const sumstat = d3.group(data, d => d.country_name);

    // Define the position of the chart 
    svg = d3.select("#chart")
    .append("svg")
    .attr('width', width + margin.left + margin.right)
    .attr('height', height + margin.top + margin.bottom)
       .append("g")
       .attr("transform", `translate(${margin.left},${margin.top})`);
 
       
    // Add X axis
    var x = d3.scaleLinear()
        .domain([0, d3.max(data, (d) => d["life_expectancy"])])
        .range([ 0, width ]);
    svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x));

    // Add Y axis
    var y = d3.scaleLinear()
        .domain([0, d3.max(data, (d) => d["fertility"])])
        .range([ height, 0]);
    svg.append("g")
        .call(d3.axisLeft(y));

    // Add a scale for bubble size
    console.log(d3.max(data, (d) => d["population"]));
    var z = d3.scaleLinear()
        .domain([0, d3.max(data, (d) => d["population"])])
        .range([ 4, 40]);

    // // Add a scale for bubble color
    // var myColor = d3.scaleOrdinal()
    //     .domain(["Asia", "Europe", "Americas"])
    //     .range(d3.schemeSet2);

    var tooltip = d3.select("#chart")
        .append("div")
        .style("opacity", 0)
        .attr("class", "tooltip")
        .style("background-color", "black")
        .style("border-radius", "5px")
        .style("padding", "10px")
        .style("color", "white")

    var showTooltip = function(e, d) {
        tooltip
        .transition()
        .duration(200)
        tooltip
        .style("opacity", 1)
        .html("Country: " + d["country_name"]+
              "<br>Life expectancy: " + d["life_expectancy"]+
              "<br>Fertility rate: " + d["fertility"])
        .style("left", (d.x+30) + "px")
        .style("top", (d.y+30) + "px")
    }
    var moveTooltip = function(d) {
        tooltip
        .style("left", (d.x+30) + "px")
        .style("top", (d.y+30) + "px")
    }
    var hideTooltip = function(d) {
        tooltip
        .transition()
        .duration(200)
        .style("opacity", 0)
    }

    console.log(data);

    // Add dots
    svg.append('g')
        .selectAll("dot")
        .data(data)
        .join("circle")
        .attr("cx", function (d) { return x(d["life_expectancy"]); } )
        .attr("cy", function (d) { return y(d["fertility"]); } )
        .attr("r", function (d) { return z(d["population"]); } )
        .style("fill", "#70b3f2")
        .style("opacity", "0.7")
        .attr("stroke", "black")
        // .style("fill", function (d) { return myColor(d.continent); } )
        // -3- Trigger the functions
        .on("mouseover", showTooltip )
        .on("mousemove", moveTooltip )
        .on("mouseleave", hideTooltip )


//     // Create a scale for x-axis 
//     const xScale = d3.scaleLinear()
//         .domain(d3.extent(data, function(d) { return d.year; }))
//         .range([ 0, width ]);

//     // Create a scale for y-axis
//     const yScale = d3.scaleLinear()
//         .domain([0, d3.max(data, function(d) { return d.value; })])
//         .range([ height, 0 ]);

//     // Define the position of each axis
//     const xAxis = d3.axisBottom(xScale).tickFormat(d3.format("d"));
//     const yAxis = d3.axisLeft(yScale);

//     // Draw axes 
//     const xAxisGroup = svg.append("g")
//         .attr('class', 'x-axis')
//         .attr('transform', `translate(0, ${height})`)
//         .call(xAxis);

//     const yAxisGroup = svg.append("g")
//         .attr('class', 'y-axis')
//         .call(yAxis)

//     // Define a scale for color 
//     const cScale = d3.scaleOrdinal()
//         .range(['#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00'])

//     // Draw the line
//     svg.selectAll(".line")
//     .data(sumstat)
//     .join("path")
//     .attr("fill", "none")
//     .attr("stroke", function(d){ return cScale(d[0]) })
//     .attr("stroke-width", 1.5)
//     .attr("d", function(d){
//         console.log(d);
//         return d3.line()
//         .x(function(d) { return xScale(d.year); })
//         .y(function(d) { return yScale(d.value); })
//         (d[1])
//     })

//     // Draw the labels for lines
//     svg.selectAll(".text")        
//         .data(sumstat)
//         .enter()
//         .append("text")
//         .attr("font-family", "sans-serif")
//         .attr("font-size", 12)
//         .attr("class","label")
//         .attr("x", function(d) { return xScale(d[1][d[1].length-1].year); }  )
//         .attr("y", function(d) { return yScale(d[1][d[1].length-1].value); })
//         .attr("fill", function(d) { return cScale(d[0])})
//         .attr("dy", ".75em")
//         .text(function(d) { return d[0]; }); 
}
