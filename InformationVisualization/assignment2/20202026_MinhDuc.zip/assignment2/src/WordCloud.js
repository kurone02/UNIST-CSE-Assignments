import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';
import cloud from 'd3-cloud';

function WordCloud({ data }) {

    useEffect(() => {
        if (!data) return;

        d3.select("#wordCloud").select("svg").remove();
        const svg = d3.select("#wordCloud").append("svg");

        let words = {};
        let total = 0;
        for(let i = 0; i < data.length; i++) {
            for(let j = 0; j < data[i].genres.length; j++) {
                let word = data[i].genres[j];
                if(word == "Ecchi" || word == "Hentai") continue;
                if(words[word] == undefined) {
                    words[word] = 0;
                }
                words[word] += data[i].score;
                total += data[i].score;
            }
        }
    
        // Set up the word cloud layout
        const layout = cloud()
          .size([800, 400])
          .words(Object.keys(words).map(d => {console.log(d, words[d] / total * 100); return ({ text: d, size: words[d] / total * 100 * 50 })}))
          .padding(5)
          .rotate(() => ~~(Math.random() * 2) * 90) // Random rotation (0 or 90 degrees)
          .fontSize(d => d.size)
          .on('end', draw);
    
        // Perform the layout computation
        layout.timeInterval(0.2);
        layout.start();
    
        // Draw the word cloud
        function draw(words) {
            
          svg.attr('width', 800)
            .attr('height', 400)
            .append('g')
            .attr('transform', 'translate(400,200)')
            .selectAll('text')
            .data(words)
            .enter()
            .append('text')
            .style('font-size', d => `${d.size}px`)
            .style('font-family', 'Arial, sans-serif')
            .style('fill', 'steelblue')
            .attr('text-anchor', 'middle')
            .attr('transform', d => `translate(${d.x}, ${d.y}) rotate(${d.rotate})`)
            .text(d => d.text);
        }
      }, [data]);

      return (
        <div id="wordCloud" style={{float: 'left', paddingLeft: "10px"}}>
      
        </div>
    )

}

export default WordCloud;