import * as d3 from 'd3';
import { useEffect } from 'react';

function BarDistribution({ data, setData }) {


    const drawBarChart = () => {
        if (!data || !data.length) return;

        // Set up dimensions and margins for the plot
        const margin = {top: 5, right: 30, bottom: 50, left: 30};

        const width = 800;
        const height = 500;

        d3.select("#barChartDistr").select("svg").remove();

        const tooltip = d3.select("#barChartDistr")
            .append("div")
            .attr("id", "tooltip")
            .style("opacity", 0)
            .attr("class", "tooltip")
            .style("background-color", "green")
            .style("border-radius", "5px")
            .style("padding", "10px")
            .style("color", "white")
            .style("position", "absolute");

        const showTooltip = function(event, d) {
            tooltip
                .transition()
                .duration(200)
            tooltip
                .style("opacity", 1)
                .html(`Score range: [${d.x0}, ${d.x1}]<br>` + 
                      `Number of anime: ${d.length}`)
                .style("left", (event.x) + "px")
                .style("top", (event.y)-100 + "px")
    
            d3.select(this)
                .transition()
                .duration(200)
                .style("opacity", 1)
                .style("stroke", "black")
            }
        
            const moveTooltip = function(event, d) {
                tooltip
                .style("left", (event.x) + "px")
                .style("top", (event.y)-100 + "px")
            }
        
            const hideTooltip = function(event, d) {
                tooltip.transition()
                       .duration(200)
                       .style("opacity", 0)
                
                d3.select(this)
                    .transition()
                    .duration(200)
                    .style("stroke", "transparent")
        }

        const selectScore = (event, d) => {
            const filtered_data = data.filter((item) => {
                return d.x0 <= item.score && item.score <= d.x1;
            });
            console.log(d.x0, d.x1);
            console.log(filtered_data);
            setData(filtered_data);
        }

        // Create an SVG container for the plot
        const svg = d3
            .select("#barChartDistr")
            .append('svg')
            .attr('width', 800)
            .attr('height', 500);

        // Indicate the x-axis label 
        svg.append("text")
        .attr("fill", "black")
        .attr("text-anchor", "end")
        .attr("x", width / 2)
        .attr("y", height)
        .attr("font-family", "sans-serif")
        .attr("font-size", 18)
        .text("Score");

        // Indicate the y-axis label 
        svg.append("text")
        .attr("fill", "black")
        .attr("text-anchor", "end")
        .attr("x", -height / 2 + 40)
        .attr("y", -margin.left / 2 + 30)
        .attr('transform', 'rotate(-90)')
        .attr("font-family", "sans-serif")
        .attr("font-size", 18)
        .text("The number of anime");

        // Calculate the histogram bins
        const binCount = 50; // Number of bins
        const scoreExtent = d3.extent(data, d => d.score);
        const xScale = d3.scaleLinear()
        .domain([0, scoreExtent[1]])
        .range([50, 750]);

        const histogram = d3.bin()
        .domain(xScale.domain())
        .thresholds(xScale.ticks(binCount));

        const bins = histogram(data.map(d => d.score));

        // Determine the maximum bin count for scaling the y-axis
        const maxBinCount = d3.max(bins, d => d.length);

        const yScale = d3.scaleLinear()
        .domain([0, maxBinCount])
        .range([450, 50]);

        // Draw the bars
        svg.selectAll('rect')
            .data(bins)
            .enter()
            .append('rect')
            .attr('class', 'distr')
            .attr('x', d => xScale(d.x0) + 1)
            .attr('y', d => yScale(d.length))
            .attr('width', d => xScale(d.x1) - xScale(d.x0))
            .attr('height', d => 450 - yScale(d.length))
            .attr('fill', 'steelblue')
            .on("click", selectScore)
            .on("mouseover", showTooltip)
            .on("mousemove", moveTooltip)
            .on("mouseleave", hideTooltip)
        ;

        // Add x-axis
        svg.append('g')
        .attr('transform', 'translate(0, 450)')
        .call(d3.axisBottom(xScale));

        // Add y-axis
        svg.append('g')
        .attr('transform', 'translate(50, 0)')
        .call(d3.axisLeft(yScale));
    };

    useEffect(drawBarChart, [data]);

    return (
        <div id="barChartDistr" style={{float: 'left', paddingLeft: "10px"}}>
      
        </div>
    )
  
};

export default BarDistribution;
