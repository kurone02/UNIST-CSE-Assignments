import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import * as d3 from 'd3'
import ScatterPlot from './ScatterPlot';
import Legend from './ScatterColorLegend';
import BarDistribution from './BarChartDistr';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import WordCloud from './WordCloud';


function App() {

  let [fullData, setFullData] = useState([]);
  const [data, setData] = useState([]);
  const [dataScatterDistr, setDataScatterDistr] = useState([]);
  const [currentType, setCurrentType] = useState("all");

  useEffect(() => {
    d3.csv("/anime.csv")   
    .then(data => {
      const filtered_data = data.filter(item => item.type && item.start_year && item.score && item.genres);
      for(let i = 0; i < filtered_data.length; i++) {
        // filtered_data[i].episodes = parseInt(filtered_data[i].episodes);
        filtered_data[i].start_year = parseInt(filtered_data[i].start_year);
        filtered_data[i].score = parseFloat(filtered_data[i].score);
        filtered_data[i].genres = JSON.parse(filtered_data[i].genres.replace(/'/g, '"'))

        // filtered_data[i].airing_from = new Date(filtered_data[i].airing_from)
        // filtered_data[i].airing_to = new Date(filtered_data[i].airing_to)
      }
      setFullData(filtered_data);
      setData(filtered_data);
      setDataScatterDistr(filtered_data);
    });
  }, []);

  useEffect(() => {
    if(!fullData.length) return;
    const filtered_data = fullData.filter((item) => currentType === "all" || item.type == currentType);
    setData(filtered_data);
    setDataScatterDistr(filtered_data);
  }, [currentType])

  return (
    <Container>
      <Row>
          <Row>
            <center>
              <h1>CSE46801 - Information Visualization</h1>
              <h2>Assignment 2: Anime Data Analysis</h2>
            </center>
          </Row>
          <Row>
            <Col sm={8}>
              <ScatterPlot 
                data={data}
                dataScatterDistr={dataScatterDistr}
                setDataScatterDistr={setDataScatterDistr}
              />
            </Col>
            <Col sm={4}>
              <Legend 
                colorScale={d3.scaleOrdinal()
                              .domain(['tv', 'ova', 'movie', 'ona', 'special', 'music'])
                              .range(['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b'])}
                currentType={currentType}
                setCurrentType={setCurrentType}
              />
            </Col>
          </Row>
          <Row>
            <Col sm={8}>
              <BarDistribution 
                data={dataScatterDistr}
                setData={setData}
              />
            </Col>
          </Row>
          <Row>
            <Col sm={8}>
              <WordCloud 
                data={dataScatterDistr}
                setData={setData}
              />
            </Col>
          </Row>
        </Row>
    
    </Container>
    
  );
}

export default App;
