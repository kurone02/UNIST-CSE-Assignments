import React from 'react';
import * as d3 from 'd3';

const Legend = ({ colorScale, currentType, setCurrentType }) => {
  const legendItems = colorScale.domain().map((category, index) => {
    const color = colorScale(category);

    const handleChooseType = () => {
        if(currentType === category) {
            setCurrentType("all");
        } else {
            setCurrentType(category);
        }
    }

    return (
      <div onClick={handleChooseType} key={index} style={{ display: 'flex', alignItems: 'center', margin: '5px' }}>
        <div style={{ width: '15px', height: '15px', backgroundColor: color, marginRight: '5px' }}></div>
        <span style={{fontSize: (currentType == category)? '24px' : '16px', fontWeight: (currentType == category)? 'bold' : null}}>{(category != null)? category : "null"}</span>
      </div>
    );
  });

  return (
    <div style={{ marginTop: '20px', width: '1000px' }}>
      <h3>Anime type</h3>
      {legendItems}
    </div>
  );
};

export default Legend;