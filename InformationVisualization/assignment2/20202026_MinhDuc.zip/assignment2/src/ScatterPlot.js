import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const ScatterPlot = ({ data, dataScatterDistr, setDataScatterDistr }) => {

  useEffect(() => {
    if (!data) return;

    d3.select("#scatterChart").select("svg").remove();

    const margin = {top: 5, right: 30, bottom: 50, left: 30};

    const width = 800;
    const height = 500;

    // Create the D3 visualization
    const svg = d3.select("#scatterChart")
        .append("svg")
      .attr('width', 800)
      .attr('height', 500)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Indicate the x-axis label 
    svg.append("text")
    .attr("fill", "black")
    .attr("text-anchor", "end")
    .attr("x", width / 2 + margin.left)
    .attr("y", height - 10)
    .attr("font-family", "sans-serif")
    .attr("font-size", 18)
    .text("Year release");

    // Indicate the y-axis label 
    svg.append("text")
    .attr("fill", "black")
    .attr("text-anchor", "end")
    .attr("x", -height / 2 + 40)
    .attr("y", -margin.left / 2 + 30)
    .attr('transform', 'rotate(-90)')
    .attr("font-family", "sans-serif")
    .attr("font-size", 18)
    .text("Score");

      const tooltip = d3.select("#scatterChart")
            .append("div")
            .attr("id", "tooltip")
            .style("opacity", 0)
            .attr("class", "tooltip")
            .style("background-color", "green")
            .style("border-radius", "5px")
            .style("padding", "10px")
            .style("color", "white")
            .style("position", "absolute");

        const showTooltip = function(event, d) {
            tooltip
                .transition()
                .duration(200)
            tooltip
                .style("opacity", 1)
                .html(`Anime: ${d.title}<br>` + 
                      `Start year: ${d.start_year}<br>` +
                      `Score: ${d.score}`)
                .style("left", (event.x) + "px")
                .style("top", (event.y) + "px")
    
            d3.select(this)
                .transition()
                .duration(200)
                .style("opacity", 1)
                .style("stroke", "black")
            }
        
            const moveTooltip = function(event, d) {
                tooltip
                .style("left", (event.x) + "px")
                .style("top", (event.y) + "px")
            }
        
            const hideTooltip = function(event, d) {
                tooltip.transition()
                       .duration(200)
                       .style("opacity", 0)
                
                d3.select(this)
                    .transition()
                    .duration(200)
                    .style("stroke", "transparent")
        }

    // Configure scales for x and y axes
    const xScale = d3.scaleLinear()
      .domain(d3.extent(data, d => d.start_year))
      .range([50, 750]);

    const yScale = d3.scaleLinear()
      .domain(d3.extent(data, d => d.score))
      .range([450, 50]);

    const cScale = d3.scaleOrdinal()
      .domain(['tv', 'ova', 'movie', 'ona', 'special', 'music'])
      .range(['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']);

    // Add circles based on the data
    svg.selectAll('circle')
      .data(data)
      .enter()
      .append('circle')
      .attr('cx', d => xScale(d.start_year))
      .attr('cy', d => yScale(d.score))
      .attr('r', 5)
      .attr('fill', d => cScale(d.type))
      .on("mouseover", showTooltip)
      .on("mousemove", moveTooltip)
      .on("mouseleave", hideTooltip)
    ;

    svg.call(
        d3.brush().extent([[50, 50],[800, 500]])
          .on('start brush', brushStart)
    );

    function brushStart(event) {
        if (!event.selection) return;
  
        const [[x0, y0], [x1, y1]] = event.selection;
        const xExtent = [xScale.invert(x0), xScale.invert(x1)];
        const yExtent = [yScale.invert(y1), yScale.invert(y0)];

        const filtered_data = data.filter((item) => {
            // console.log(yExtent[1], item.score, yExtent[0]);
            return xExtent[0] <= item.start_year && item.start_year <= xExtent[1] &&
                   yExtent[0] <= item.score && item.score <= yExtent[1];
        });
        // console.log(filtered_data);
        setDataScatterDistr(filtered_data);
      }

    // Add x-axis
    const xAxis = d3.axisBottom(xScale).ticks(10).tickFormat(d3.format('d'));
    svg.append('g')
      .attr('transform', 'translate(0, 450)')
      .call(xAxis);

    // Add y-axis
    const yAxis = d3.axisLeft(yScale);
    svg.append('g')
      .attr('transform', 'translate(50, 0)')
      .call(yAxis);

    

  }, [data]);

  return (
    <div id="scatterChart" style={{float: 'left', paddingLeft: "10px"}}>
      
    </div>
  );
};

export default ScatterPlot;
