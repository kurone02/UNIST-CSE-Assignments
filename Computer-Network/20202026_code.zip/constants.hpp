#ifndef CONSTANTS_H
#define CONSTANTS_H

const int BACK_LOG = 1024;

#endif