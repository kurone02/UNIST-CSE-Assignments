#ifndef UTILS_H
#define UTILS_H

#include <cstddef>
#include <cstdlib>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <netinet/in.h>

// Function to convert an IP address to 32-bit integer
in_addr_t ipStringtoInt(const std::string &ip);

// Function to read content from a file
std::string readFile(const std::ifstream &file);

// Function to extract the request URL from an HTTP request
// Assume that httpRequest is a GET request
std::string extractGetRequestURL(const std::string &httpRequest);

#endif