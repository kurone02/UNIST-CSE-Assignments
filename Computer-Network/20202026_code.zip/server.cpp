#include "cache.hpp"
#include "utils.hpp"
#include "socket.hpp"
#include "constants.hpp"
#include "multiplexing.hpp"

int main(int argc, char *argv[]) {
    using namespace std;

    if(argc < 5) {
        std::cerr << "Wrong command!\n"
                  << "Usage: ./server <server IP> <port number> <web object directory path> <cache size in KB> [optional: <number of threads, default=4>]"
                  << std::endl; 
        return -1;
    }

    // Initialize
    Cache &cache = Cache::instance();
    in_addr_t server_addr = ipStringtoInt(argv[1]);
    in_port_t server_port = stoi(argv[2]);
    string web_dir = argv[3];
    size_t cache_size = stoul(argv[4]);
    size_t nThreads = 4;
    if(argc >= 6) {
        nThreads = stoul(argv[5]);
    }

    // Set the maximum cache size (input is in bytes)
    cache.setMaxCacheSize(cache_size * 1000);
 
    // Create a socket    
    int serverSocket = createServerSocket(server_addr, server_port);
    // Bind to a port
    bindSocket(serverSocket, server_port, server_addr);
    // Listen for incoming connections
    if (listen(serverSocket, BACK_LOG) < 0) {
        std::cerr << "Error: Listening failed" << std::endl;
        close(serverSocket);
        return -1;
    }

    std::cout << "Server listening on port " << server_port << "..." << std::endl;

    multiThreading(nThreads, web_dir, serverSocket);

    // Close the server socket
    close(serverSocket);

    return 0;
}
