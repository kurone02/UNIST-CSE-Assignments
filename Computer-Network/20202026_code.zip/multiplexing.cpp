#include "multiplexing.hpp"

//  Callback function to send an HTML response
void responseCallback(struct ev_loop* loop, struct ev_io* w, int revents) {
    int clientSocket = w->fd;
    std::string web_dir = *(std::string*)(w->data);

    // Receive the HTTP request
    char buffer[4096] = {0};
    int read_bytes = recv(clientSocket, buffer, sizeof(buffer), 0);

    if(read_bytes < 0) {
        std::cerr << "Error: Reading client's requests failed" << std::endl;
        // Stop and release the libev watcher for the client socket
        ev_io_stop(loop, w);
        // Close the client socket and release the libev watcher
        close(clientSocket);
        delete w;
        return;
    }

    std::string httpRequest(buffer);

    // Check if it's a valid HTTP GET request
    if (httpRequest.find("GET ") == std::string::npos) {
        // Invalid request, send "Bad Request" (400) response
        std::string response = "HTTP/1.1 400 Bad Request\r\n\r\n";
        sendResponse(clientSocket, response);
        // Stop and release the libev watcher for the client socket
        ev_io_stop(loop, w);
        // Close the client socket and release the libev watcher
        close(clientSocket);
        delete w;
        return;
    }

    // Get the requested file path
    const std::string reqURL = extractGetRequestURL(httpRequest);
    const std::string filePath = web_dir + reqURL;

    // Read the requested file
    std::ifstream reqFile(filePath);
    std::string response = "";

    // Fail to read the file
    if(reqFile.fail()) {
        response += "HTTP/1.1 404 Not Found\r\n\r\n";
    } else {
        // Valid GET request, send a sample response
        response += "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n";
        Cache &cache = Cache::instance();
        if(cache.contains(reqURL)) {
            response += cache.get(reqURL);
        } else {
            std::string fileContent = readFile(reqFile);
            response += fileContent;
            cache.insert(reqURL, fileContent);
        }
    }

    sendResponse(clientSocket, response);

    // Stop and release the libev watcher for the client socket
    ev_io_stop(loop, w);

    // Close the client socket and release the libev watcher
    close(clientSocket);
    delete w;
}

// Callback function to handle client connections
void acceptCallback(struct ev_loop* loop, struct ev_io* watcher, int revents) {
    if (EV_ERROR & revents) {
        std::cerr << "Error: Invalid event" << std::endl;
        return;
    }

    int serverSocket = watcher->fd;

    sockaddr_in clientSin;
    socklen_t addrLen = sizeof(clientSin);

    // Accept a client connection
    int clientSocket = accept(serverSocket, (struct sockaddr*)&clientSin, &addrLen);
    if (clientSocket < 0) {
        std::cerr << "Error: Accepting client connection failed" << std::endl;
        return;
    }

    // Initialize a new libev watcher for the client socket
    struct ev_io* clientWatcher = new ev_io;
    clientWatcher->data = watcher->data;
    ev_io_init(clientWatcher, responseCallback, clientSocket, EV_READ);

    // Start the libev watcher
    ev_io_start(loop, clientWatcher);
}

// Function to create io multiplexing with multiple threads
void multiThreading(size_t nThreads, std::string web_dir, int serverSocket) {
    // Create a vector of threads and libev event loops
    std::vector<std::thread> threads(nThreads);
    std::vector<struct ev_loop*> loops(nThreads);

    // Start the threads
    for (size_t i = 0; i < nThreads; ++i) {
        loops[i] = ev_loop_new(EVFLAG_AUTO);
        threads[i] = std::thread([loops, i, &web_dir, serverSocket]() {
            // Create an I/O watcher for libev
            ev_io io_watcher;
            io_watcher.data = &web_dir;
            ev_io_init(&io_watcher, acceptCallback, serverSocket, EV_READ);
            ev_io_start(loops[i], &io_watcher);

            // Run the libev event loop for this thread
            ev_run(loops[i], 0);
        });
    }

    // Join the threads (waits for all threads to finish)
    for (size_t i = 0; i < nThreads; ++i) {
        threads[i].join();
    }
}