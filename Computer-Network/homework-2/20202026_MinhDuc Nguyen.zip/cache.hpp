#ifndef CACHE_H
#define CACHE_H

#include <unordered_map>
#include <iterator>
#include <mutex>
#include <cstddef>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <iterator>

class Cache {
private:
    struct TData {
        int accessCount;
        std::string content;
    };
    typedef std::unordered_map<std::string, TData>::iterator CacheIterator;

    static Cache* singleton_;
    Cache(): maxCacheSize(0), currentSize(0) { }

    size_t maxCacheSize;
    size_t currentSize;
    std::mutex mutex;
    std::unordered_map<std::string, TData> cache;
public:
    static Cache& instance() { static Cache inst; return inst; }
    void setMaxCacheSize(const size_t &maxCache) { maxCacheSize = maxCache; }
    bool contains(const std::string& key);
    std::string get(const std::string& key);
    void insert(const std::string& key, const std::string& value);
    void remove(const std::string& key);
};

#endif