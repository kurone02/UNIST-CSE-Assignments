#ifndef MULTIPLEXING_H
#define MULTIPLEXING_H


#include <iostream>
#include <cstddef>
#include <cstdlib>
#include <string>
#include <algorithm>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <ev.h>
#include <thread>

#include "utils.hpp"
#include "socket.hpp"
#include "cache.hpp"


//  Callback function to send an HTML response
void responseCallback(struct ev_loop* loop, struct ev_io* w, int revents);

// Callback function to handle client connections
void acceptCallback(struct ev_loop* loop, struct ev_io* watcher, int revents);

// Function to create io multiplexing with multiple threads
void multiThreading(size_t nThreads, std::string web_dir, int serverSocket);

#endif