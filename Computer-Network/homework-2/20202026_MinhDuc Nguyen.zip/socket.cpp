#include "socket.hpp"

// Function to send an HTTP response
void sendResponse(int clientSocket, const std::string& response) {
    send(clientSocket, response.c_str(), response.size(), 0);
}

// Function to create a server socket
int createServerSocket(in_addr_t server_addr, in_port_t server_port) {
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        throw std::runtime_error("Socket creation failed");
    }

    int optval = 1;
    if (setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0) {
        close(serverSocket);
        throw std::runtime_error("Port reuse failed");
    }

    return serverSocket;
}

// Function to bind a server socket to a port
void bindSocket(int serverSocket, in_port_t server_port, in_addr_t server_addr) {
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(server_port);
    serverAddr.sin_addr.s_addr = server_addr;

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        close(serverSocket);
        throw std::runtime_error("Binding failed");
    }
}