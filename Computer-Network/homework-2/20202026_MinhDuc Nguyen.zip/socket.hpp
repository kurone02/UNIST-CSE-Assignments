#ifndef SOCKET_H
#define SOCKET_H

#include <unistd.h>
#include <stdexcept>
#include <string>
#include <sys/socket.h>
#include <netinet/in.h>

// Function to send an HTTP response
void sendResponse(int clientSocket, const std::string& response);

// Function to create a server socket
int createServerSocket(in_addr_t server_addr, in_port_t server_port);

// Function to bind a server socket to a port
void bindSocket(int serverSocket, in_port_t server_port, in_addr_t server_addr);

#endif