#include "utils.hpp"

// Function to convert an IP address to 32-bit integer
in_addr_t ipStringtoInt(const std::string &ip) {
    std::vector<int> components;
    std::stringstream ss(ip);
    std::string component;
    
    while (std::getline(ss, component, '.')) { 
        components.push_back(std::stoi(component));
    }

    if (components.size() != 4) {
        throw std::invalid_argument("Invalid IP address format");
    }

    in_addr_t result = 0;
    for (int i = 0; i < 4; ++i) {
        result |= (static_cast<in_addr_t>(components[i]) << (24 - 8 * i));
    }

    return result;
}

// Function to read content from a file
std::string readFile(const std::ifstream &file) {
    std::ostringstream sstr;
    sstr << file.rdbuf();
    return sstr.str();
}

// Function to extract the request URL from an HTTP request
// Assume that httpRequest is a GET request
std::string extractGetRequestURL(const std::string &httpRequest) {
    size_t startURL = httpRequest.find("GET ");
    size_t endURL = httpRequest.find(" ", startURL + 4);

    // Invalid request, no end of URL found
    if (endURL == std::string::npos) {
        return "";
    }

    // Extract the URL substring
    return httpRequest.substr(startURL + 4, endURL - startURL - 4);
}