#include "cache.hpp"

// Function to check if the requested content is in the cache
bool Cache::contains(const std::string &key) {
    std::lock_guard<std::mutex> lock(mutex);
    return cache.find(key) != cache.end();
}

// Function to get the cache content
std::string Cache::get(const std::string& key) {
    std::lock_guard<std::mutex> lock(mutex);
    cache[key].accessCount += 1;
    return cache[key].content;
}

// Function to add a key-value pair to the cache
void Cache::insert(const std::string& key, const std::string& value) {
    if(value.size() > maxCacheSize) {
        return;
    }
    std::lock_guard<std::mutex> lock(mutex);
    // Check if adding the new entry exceeds the maximum cache size
    // If yes, remove based on LFU policy
    while(currentSize + value.size() > maxCacheSize) {
        // Least Frequently Used
        CacheIterator min_it = cache.begin();
        for(CacheIterator it = std::next(cache.begin()); it != cache.end(); it++) {
            if(it->second.accessCount < min_it->second.accessCount) {
                min_it = it;
            }
        }
        // Drop from cache
        currentSize -= min_it->second.content.size();
        cache.erase(min_it);
    }
    // Insert to cache
    cache[key] = {1, value};
    currentSize += value.size();
}

// Function to add a key-value pair to the cache
void Cache::remove(const std::string& key) {
    std::lock_guard<std::mutex> lock(mutex);
    if(!contains(key)) return;
    currentSize -= cache[key].content.size();
    cache.erase(key);
}