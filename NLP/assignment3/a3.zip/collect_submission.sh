rm -f assignment3.zip
zip -r assignment3coding.zip *.ipynb
