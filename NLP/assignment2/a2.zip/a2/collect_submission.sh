rm -f assignment2.zip
zip -r assignment2coding.zip *.py *.png saved_params_40000.npy
